DON'T APPLY THE MIGRATIONSCRIPTS!

They were intendet to be used in combination with a WTableDirEditor. Since this editor seems not to work if it has not a database column, the panel uses a plain Combobox.